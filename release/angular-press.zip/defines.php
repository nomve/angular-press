<?php

define( 'ANGULAR_PRESS_PLUGIN_FILE', __DIR__ . '/angular-press.php' );